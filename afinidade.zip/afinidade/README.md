# Afinidade

Recomendação musical em Java 17 e Spring Boot: **notas de 0 a 4, servidor TCP concorrente e interface web**.

O banco H2 começa vazio: nenhum artista, usuário ou avaliação é inserido automaticamente. As tabelas são criadas na primeira execução. Dados inseridos posteriormente continuam salvos entre reinícios; iniciar a aplicação não apaga o banco.

A interface mostra o catálogo vazio e desabilita as avaliações enquanto não houver perfil. Esta versão ainda não possui tela ou API de cadastro de usuários e artistas. O algoritmo mantém a estrutura de 15 artistas prevista no trabalho; para usá-lo, é necessário cadastrar os dados no banco. Os dados fictícios usados nos testes ficam apenas em bases temporárias.

## Estrutura

```text
src/afinidade/          código Java (8 arquivos)
web/                   HTML, CSS e JavaScript
test/afinidade/         testes
application.properties configuração de portas e banco
pom.xml                único projeto Maven
iniciar.ps1            execução no Windows
mvnw / mvnw.cmd        Maven automático
.mvn/                  configuração do Maven Wrapper
```

`target/` é gerada pela compilação. `data/` guarda as avaliações. Nenhuma das duas é código-fonte. As pastas Java usam apenas o pacote `afinidade`, sem a sequência de subpastas anterior.

## Rodar no VS Code

Requisito: **JDK 17 a 25**, com `JAVA_HOME` apontando para sua pasta (não para `bin`). Não precisa instalar Maven. A primeira compilação precisa de internet.

1. Abra esta pasta no VS Code.
2. Abra um terminal PowerShell.
3. Execute:

```powershell
powershell -ExecutionPolicy Bypass -File .\iniciar.ps1
```

Abra **http://127.0.0.1:8080**. Para encerrar, pressione **Ctrl+C no terminal**. Depois de editar o código, execute o mesmo comando: ele recompila antes de iniciar.

Se precisar configurar o JDK no terminal, use o caminho real da sua instalação:

```powershell
$env:JAVA_HOME = 'C:\caminho\para\seu\jdk-17'
```

Se 8080 estiver ocupada, encerre a execução anterior ou use:

```powershell
powershell -ExecutionPolicy Bypass -File .\iniciar.ps1 -PortaWeb 8081
```

Nesse caso, abra http://127.0.0.1:8081. Se uma versão anterior ainda estiver usando 9090, encerre-a ou acrescente `-PortaTcp 9091`.

## Demonstrar a aplicação distribuída

O modo padrão inicia tudo em um processo para facilitar o uso. A interface **continua acessando os dados por um socket TCP real**. Para demonstrar dois processos independentes, compile uma vez:

```powershell
.\mvnw.cmd package
```

Em um terminal:

```sh
java -jar target/afinidade.jar servidor
```

Em outro:

```sh
java -jar target/afinidade.jar cliente
```

Outros clientes podem usar o mesmo servidor:

```sh
java -jar target/afinidade.jar cliente --server.port=8081
```

Em máquinas diferentes, o servidor usa `--music.tcp.host=0.0.0.0` e o cliente usa `--music.server.host=IP_DO_SERVIDOR`. Libere a porta TCP 9090 na rede do laboratório. As opções também podem ser alteradas em `application.properties`.

## Como o código funciona

```text
Navegador → WebController → TcpClient → TCP :9090 → TcpServer
                                                       ├─ MusicRepository → H2
                                                       └─ RecommendationService
```

`App` inicia a aplicação. `Models` contém os dados trocados. `Protocol` define JSON por linha e os erros. O cliente web não consulta o banco diretamente. O servidor tem 32 threads e uma fila limitada; cada conexão pode enviar várias mensagens. Gravações são transacionais e usam uma versão para impedir que dois clientes sobrescrevam o mesmo perfil silenciosamente. As avaliações sobrevivem a reinícios.

## Recomendação

Cada usuário tem um vetor de 15 posições. **0 significa desconhecido**, 1 não gosto, 2 gosto muito pouco, 3 gosto e 4 gosto muito.

```text
I = posições avaliadas pelos dois usuários (ambas as notas > 0)
d(A,B) = sqrt( soma de (A[i] - B[i])², para i em I )
```

Sem posições em comum, o usuário não é um vizinho válido. A raiz quadrada faz parte da distância: no exemplo do enunciado cuja soma dos quadrados é 2, a distância é √2 ≈ 1,4142.

São escolhidos os `k` vizinhos mais próximos (padrão 3). Empates priorizam mais notas em comum e depois o menor ID. Para artistas que o alvo ainda não avaliou, calculamos a média ponderada das notas dos vizinhos, com peso `1/(1+distância)`. Notas zero são ignoradas; notas 1 e 2 participam da média. Apenas médias a partir de 3 viram sugestões. Não há normalização por quantidade de avaliações em comum; essa quantidade aparece na interface.

## Testes e protocolo

```powershell
.\mvnw.cmd verify
```

Os testes verificam o cálculo, zeros, persistência, validações, conflitos e **24 clientes TCP simultâneos**. Usam bases temporárias e não alteram suas avaliações.

TCP usa JSON UTF-8 terminado por quebra de linha, até 65.536 caracteres. Operações:

```json
{"operation":"PING"}
{"operation":"CATALOG"}
{"operation":"RECOMMEND","userId":1,"k":3,"limit":5}
{"operation":"UPDATE_RATINGS","userId":1,"version":0,"ratings":[4,3,4,3,0,1,0,3,4,4,2,0,3,2,3]}
```

No salvamento, use a versão atual retornada pelo catálogo. As respostas têm `ok`, `code`, `message` e `data`. A API web expõe `/api/health`, `/api/catalog`, `/api/users/{id}/recommendations` e `PUT /api/users/{id}/ratings`.

Projeto acadêmico, sem autenticação, sem TLS e sem integração com serviços de música. Use em ambiente local ou laboratório confiável.
